import React, { useState } from 'react';

function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    // Add login API logic here
  };

  return (
    <div className="flex justify-center items-center h-screen">
      <form onSubmit={handleSubmit} className="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4">
        <h2 className="text-xl font-bold text-center mb-4">Login</h2>
        <input type="email" placeholder="Email" className="mb-4 p-2 border w-full" value={email} onChange={e => setEmail(e.target.value)} required />
        <input type="password" placeholder="Password" className="mb-4 p-2 border w-full" value={password} onChange={e => setPassword(e.target.value)} required />
        <button type="submit" className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded w-full">Login</button>
      </form>
    </div>
  );
}

export default Login;