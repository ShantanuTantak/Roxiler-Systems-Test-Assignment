import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Login from './pages/Login';
import Register from './pages/Register';
import Dashboard from './pages/Dashboard';
import StoreList from './pages/StoreList';
import Navbar from './components/Navbar';

function App() {
  return (
    <Router>
      <div className="bg-gradient-to-r from-purple-300 via-pink-300 to-red-300 min-h-screen">
        <Navbar />
        <Routes>
          <Route path="/" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/stores" element={<StoreList />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;