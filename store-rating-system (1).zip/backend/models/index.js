const { Sequelize, DataTypes } = require('sequelize');
const sequelize = new Sequelize('store_rating', 'username', 'password', {
  host: 'localhost',
  dialect: 'postgres',
});

const User = sequelize.define('User', {
  name: DataTypes.STRING,
  email: DataTypes.STRING,
  password: DataTypes.STRING,
  address: DataTypes.STRING,
  role: DataTypes.STRING,
});

const Store = sequelize.define('Store', {
  name: DataTypes.STRING,
  email: DataTypes.STRING,
  address: DataTypes.STRING,
});

const Rating = sequelize.define('Rating', {
  value: DataTypes.INTEGER,
});

User.hasMany(Rating);
Store.hasMany(Rating);
Rating.belongsTo(User);
Rating.belongsTo(Store);

module.exports = { sequelize, User, Store, Rating };